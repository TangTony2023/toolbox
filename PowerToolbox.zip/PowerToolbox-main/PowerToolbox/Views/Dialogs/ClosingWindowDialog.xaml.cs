﻿using Microsoft.UI.Xaml.Controls;

namespace PowerToolbox.Views.Dialogs
{
    /// <summary>
    /// 任务下载中提示对话框
    /// </summary>
    public sealed partial class ClosingWindowDialog : ContentDialog
    {
        public ClosingWindowDialog()
        {
            InitializeComponent();
        }
    }
}

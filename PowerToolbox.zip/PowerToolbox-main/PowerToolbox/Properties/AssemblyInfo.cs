﻿using System.Reflection;
using System.Resources;

// 程序集信息设置
[assembly: AssemblyCompany("高怡飞")]
[assembly: AssemblyCopyright("Copyright 2022-2025 高怡飞 版权所有")]
[assembly: AssemblyDescription("PowerToolbox")]
[assembly: AssemblyFileVersion("4.7.1105.0")]
[assembly: AssemblyInformationalVersion("4.7.1105.0")]
[assembly: AssemblyProduct("PowerToolbox")]
[assembly: AssemblyTitle("PowerToolbox")]
[assembly: AssemblyVersion("4.7.1105.0")]

// 应用程序默认区域性的资源控制器设置
[assembly: NeutralResourcesLanguage("en-us")]

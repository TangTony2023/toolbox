﻿namespace PowerToolbox.Extensions.DataType.Enums
{
    /// <summary>
    /// 驱动安装类型
    /// </summary>
    public enum DriverInstallKind
    {
        InstallDriver = 0,
        UnInstallDriver = 1,
    }
}

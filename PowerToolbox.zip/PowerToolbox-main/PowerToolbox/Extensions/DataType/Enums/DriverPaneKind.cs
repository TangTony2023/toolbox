﻿namespace PowerToolbox.Extensions.DataType.Enums
{
    /// <summary>
    /// 驱动浮出面板类型
    /// </summary>
    public enum DriverPaneKind
    {
        UseInstruction = 0,
        TaskManager = 1,
    }
}

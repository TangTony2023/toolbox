﻿namespace PowerToolbox.Extensions.DataType.Enums
{
    /// <summary>
    /// 编辑菜单类型
    /// </summary>
    public enum ShellEditKind
    {
        AddMenu = 0,
        EditMenu = 1
    }
}

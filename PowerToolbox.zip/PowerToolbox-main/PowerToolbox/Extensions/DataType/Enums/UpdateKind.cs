﻿namespace PowerToolbox.Extensions.DataType.Enums
{
    /// <summary>
    /// 模拟更新页面类型
    /// </summary>
    public enum SimulateUpdateKind
    {
        Windows11 = 0,
        Windows10 = 1
    }
}

﻿namespace PowerToolbox.Extensions.DataType.Class
{
    public class SunTimes
    {
        public int SunriseHour;
        public int SunriseMinute;
        public int SunsetHour;
        public int SunsetMinute;
        public string Text;
        public bool HasSunrise;
        public bool HasSunset;
        public bool IsPolarDay;
        public bool IsPolarNight;
    }
}

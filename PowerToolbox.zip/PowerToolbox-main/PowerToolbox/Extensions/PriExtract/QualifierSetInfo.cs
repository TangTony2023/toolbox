﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class QualifierSetInfo
    {
        public ushort FirstQualifierIndexIndex { get; set; }

        public ushort NumQualifiersInSet { get; set; }
    }
}

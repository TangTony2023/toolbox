﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class ItemInfo
    {
        public uint Decision { get; set; }

        public uint FirstCandidate { get; set; }
    }
}

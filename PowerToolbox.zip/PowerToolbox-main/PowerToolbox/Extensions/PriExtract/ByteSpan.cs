﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class ByteSpan
    {
        public long Offset { get; set; }

        public uint Length { get; set; }
    }
}

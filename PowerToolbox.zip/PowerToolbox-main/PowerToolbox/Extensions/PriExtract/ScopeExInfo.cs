﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class ScopeExInfo
    {
        public ushort ScopeIndex { get; set; }

        public ushort ChildCount { get; set; }

        public ushort FirstChildIndex { get; set; }
    }
}

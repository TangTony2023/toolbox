﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class ItemToItemInfoGroup
    {
        public uint FirstItem { get; set; }

        public uint ItemInfoGroup { get; set; }
    }
}

﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class DecisionInfo
    {
        public ushort FirstQualifierSetIndexIndex { get; set; }

        public ushort NumQualifierSetsInDecision { get; set; }
    }
}

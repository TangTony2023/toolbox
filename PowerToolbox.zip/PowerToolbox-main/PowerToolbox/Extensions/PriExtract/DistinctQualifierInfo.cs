﻿using PowerToolbox.Extensions.DataType.Enums;

namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class DistinctQualifierInfo
    {
        public QualifierType QualifierType { get; set; }

        public uint OperandValueOffset { get; set; }
    }
}

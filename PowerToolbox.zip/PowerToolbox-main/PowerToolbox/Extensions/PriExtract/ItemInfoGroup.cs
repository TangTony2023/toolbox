﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class ItemInfoGroup
    {
        public uint GroupSize { get; set; }

        public uint FirstItemInfo { get; set; }
    }
}

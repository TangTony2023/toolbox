﻿namespace PowerToolbox.Extensions.PriExtract
{
    public sealed class QualifierInfo
    {
        public ushort Index { get; set; }

        public ushort Priority { get; set; }

        public ushort FallbackScore { get; set; }
    }
}
